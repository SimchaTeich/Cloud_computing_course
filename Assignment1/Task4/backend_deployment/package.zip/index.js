/*----------------------------------------------------------------------------------------------------
/ Great Thanks to:
/ https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/javascript_s3_code_examples.html
/ about the listing objects from s3
/----------------------------------------------------------------------------------------------------*/
const { S3Client, ListObjectsV2Command } = require("@aws-sdk/client-s3");
const region     = "us-east-1";
const bucketName = "mymp4bucket";
const client = new S3Client({region});
  
async function get_bucket_objects_list()
{
    const command = new ListObjectsV2Command({
        Bucket: bucketName
    });

    try
    {
        // get list of objects from s3
        const { Contents } = await client.send(command);

        // exstract just the filenames (filename is key)
        const contentsList = Contents.map((c) => `${c.Key}`);
        
        // return a json list (type is string..)
        return JSON.stringify(contentsList);
        
    } catch (err) { console.error(err);}
}



/*----------------------------------------------------------------------------------------------------
/ Great Thanks to:
/ https://github.com/meni432/ariel-cloud/blob/main/presign/operations-demo.js
/ about the presign demo
/----------------------------------------------------------------------------------------------------*/
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { GetObjectCommand } = require("@aws-sdk/client-s3");


async function get_video_URL(video_name)
{
    const bucket = "mymp4bucket";
    const key    = video_name;
    const region = "us-east-1";

    const client = new S3Client({ region });

    const getObjectParams = {
        Bucket: bucket,
        Key: key,
    };

    const command = new GetObjectCommand(getObjectParams);
    const url = await getSignedUrl(client, command, { expiresIn: 3600 });
    return url;
}



/*----------------------------------------------------------------------------------------------------
/ Great Thanks to:
/ https://github.com/meni432/ariel-cloud/blob/main/demos/03-fib-user-data
/ about the express application
/----------------------------------------------------------------------------------------------------*/
const express = require('express');
const app = express();

app.get('/videoList', async (req, res) => {
    let result = await get_bucket_objects_list();
    console.log("GET request for /videoList");
    res.contentType('application/json');
    res.send(result);
});

app.get('/videoLink', async (req, res) => {
    if (req.query.video_name)
    {
        let result = await get_video_URL(req.query.video_name);
        console.log("GET request for /videoLink?video_name="+req.query.video_name);
        console.log(result);
        res.send(result);
    }
    else
    {
        res.send("Error: where is my video_name GET parameter?...");
    }
});

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});
